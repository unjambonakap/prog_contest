import Debug.Trace
import Text.Printf

above :: Double -> Double -> Double
above r y | y > r = 0
above r y | y < -r = pi * r * r
above r y = r * r * (asin 1 - asin (y/r))

wedge :: Double -> Double -> Double -> Double
wedge r x y | x^2 + y^2 > r^2 = 0
wedge r x y | x < 0 = above r y - wedge r (-x) y
wedge r x y = (above r y - above r y') / 2 - x * (y' - y)
  where y' = sqrt (r^2 - x^2)

square :: Double -> (Double, Double) -> (Double, Double) -> Double
square r (x0, y0) _ | x0^2 + y0^2 > r^2 = 0
square r (x0, y0) (x1, y1) | x1^2 + y1^2 < r^2 = (x1 - x0) * (y1 - y0)
square r (x0, y0) (x1, y1) = wedge r x0 y0 - wedge r x0 y1 - wedge r x1 y0 + wedge r x1 y1

solve :: [Double] -> Double
solve [fly, outer, rim, string, gap] = if inner < 0 then 1
                                       else if smallGap < 0 then 1
                                            else 1 - (sum [ square inner (x + width, y + width) (x + width + smallGap, y + width + smallGap)
                                                          | x <- [0, spacing..outer], y <- [0, spacing..outer] ]) / total
  where inner = outer - rim - fly
        spacing = gap + 2 * string
        width = fly + string
        smallGap = spacing - 2 * width
        total = pi * outer * outer / 4

main :: IO ()
main = interact $ unlines . zipWith (++) [ "Case #" ++ show i ++ ": " | i <- [1..] ] . map (printf "%.6f" . solve . map read . words) . tail . lines
